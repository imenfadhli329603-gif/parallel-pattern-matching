import matplotlib.pyplot as plt
import io
import pandas as pd

# 1. I tuoi dati, copiati esattamente dalla tabella di PowerShell
dati_csv = """Threads,TempoMedio(s),DeviazioneStandard(s),Speedup
1,7.9519,3.30707,1
2,4.1156,1.71909,1.93214
4,1.8547,0.282782,4.28743
8,1.2917,0.0717301,6.15615
12,1.3449,0.114506,5.91263
16,1.2967,0.113233,6.13241
24,1.2713,0.113682,6.25494
32,1.3471,0.124434,5.90298
64,1.328,0.138936,5.98788
"""

# 2. Leggiamo i dati usando la libreria pandas
# Questo converte il testo in una tabella che Python può usare
df = pd.read_csv(io.StringIO(dati_csv))

# Estraiamo le colonne che ci servono
threads = df['Threads']
tempo_medio = df['TempoMedio(s)']
speedup = df['Speedup']

# --- GRAFICO 1: SPEEDUP ---
print("Sto creando il grafico dello Speedup...")

# Crea una nuova figura e un set di assi
plt.figure(figsize=(10, 6)) # Dimensioni del grafico (larghezza, altezza in pollici)
plt.plot(threads, speedup, marker='o', linestyle='-', color='b') # 'o' per i punti, '-' per la linea, 'b' per blu

# Aggiungi i titoli e le etichette (in inglese, come da convenzione scientifica)
plt.title('Speedup vs. Number of Threads', fontsize=16)
plt.xlabel('Number of Threads', fontsize=12)
plt.ylabel('Speedup', fontsize=12)

# Aggiungi una griglia per una migliore leggibilità
plt.grid(True, which='both', linestyle='--', linewidth=0.5)

# Aggiungi una linea orizzontale per lo speedup ideale (opzionale, ma bello da vedere)
# plt.plot(threads, threads, linestyle='--', color='r', label='Ideal Speedup')
# plt.legend()

# Salva il grafico come file immagine PNG
plt.savefig('grafico_speedup.png')
print("Grafico 'grafico_speedup.png' salvato nella cartella.")


# --- GRAFICO 2: TEMPO DI ESECUZIONE ---
print("\nSto creando il grafico del Tempo di Esecuzione...")

# Crea una nuova figura
plt.figure(figsize=(10, 6))
plt.plot(threads, tempo_medio, marker='s', linestyle='-', color='g') # 's' per quadrati, 'g' per verde

# Aggiungi i titoli e le etichette
plt.title('Execution Time vs. Number of Threads', fontsize=16)
plt.xlabel('Number of Threads', fontsize=12)
plt.ylabel('Average Execution Time (s)', fontsize=12)

# Aggiungi la griglia
plt.grid(True, which='both', linestyle='--', linewidth=0.5)

# Salva il secondo grafico
plt.savefig('grafico_tempo_esecuzione.png')
print("Grafico 'grafico_tempo_esecuzione.png' salvato nella cartella.")

print("\nFatto! Controlla la tua cartella per i file PNG.")

