#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
#include <chrono>
#include <algorithm>
#include <omp.h>
#include <stdint.h>

// =======================================================
// 1. Contenuto di des_consts.h (Definizioni e Dichiarazioni)
// =======================================================
#define DES_CONST
DES_CONST int dev_PC_1[56] = { 57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36, 63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4 };
DES_CONST int dev_PC_2[48] = { 14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2, 41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32 };
DES_CONST int dev_IP[64] = { 58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4, 62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8, 57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3, 61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7 };
DES_CONST int dev_E_BIT[48] = { 32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17, 16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1 };
DES_CONST int dev_S1[64] = { 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7, 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8, 4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0, 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13 };
DES_CONST int dev_S2[64] = { 15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10, 3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5, 0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15, 13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9 };
DES_CONST int dev_S3[64] = { 10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8, 13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1, 13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7, 1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12 };
DES_CONST int dev_S4[64] = { 7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15, 13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9, 10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4, 3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14 };
DES_CONST int dev_S5[64] = { 2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9, 14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6, 4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14, 11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3 };
DES_CONST int dev_S6[64] = { 12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11, 10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8, 9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6, 4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13, };
DES_CONST int dev_S7[64] = { 4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1, 13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6, 1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2, 6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12, };
DES_CONST int dev_S8[64] = { 13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7, 1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2, 7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8, 2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11, };
DES_CONST int* dev_S[8] = { dev_S1, dev_S2, dev_S3, dev_S4, dev_S5, dev_S6, dev_S7, dev_S8 };
DES_CONST int dev_P[32] = { 16, 7, 20, 21, 29, 12, 28, 17, 1, 15, 23, 26, 5, 18, 31, 10, 2, 8, 24, 14, 32, 27, 3, 9, 19, 13, 30, 6, 22, 11, 4, 25 };
DES_CONST int dev_IP_REV[64] = { 40, 8, 48, 16, 56, 24, 64, 32, 39, 7, 47, 15, 55, 23, 63, 31, 38, 6, 46, 14, 54, 22, 62, 30, 37, 5, 45, 13, 53, 21, 61, 29, 36, 4, 44, 12, 52, 20, 60, 28, 35, 3, 43, 11, 51, 19, 59, 27, 34, 2, 42, 10, 50, 18, 58, 26, 33, 1, 41, 9, 49, 17, 57, 25 };
DES_CONST int dev_SHIFTS[16] = { 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 };
int h_PC_1[56], h_PC_2[48], h_IP[64], h_E_BIT[48], h_S1[64], h_S2[64], h_S3[64], h_S4[64], h_S5[64], h_S6[64], h_S7[64], h_S8[64];
int* h_S[8] = { h_S1, h_S2, h_S3, h_S4, h_S5, h_S6, h_S7, h_S8 };
int h_P[32], h_IP_REV[64], h_SHIFTS[16];
void init_des_consts() {
    memcpy(h_PC_1, dev_PC_1, sizeof(dev_PC_1)); memcpy(h_PC_2, dev_PC_2, sizeof(dev_PC_2)); memcpy(h_IP, dev_IP, sizeof(dev_IP)); memcpy(h_E_BIT, dev_E_BIT, sizeof(dev_E_BIT));
    memcpy(h_S1, dev_S1, sizeof(dev_S1)); memcpy(h_S2, dev_S2, sizeof(dev_S2)); memcpy(h_S3, dev_S3, sizeof(dev_S3)); memcpy(h_S4, dev_S4, sizeof(dev_S4));
    memcpy(h_S5, dev_S5, sizeof(dev_S5)); memcpy(h_S6, dev_S6, sizeof(dev_S6)); memcpy(h_S7, dev_S7, sizeof(dev_S7)); memcpy(h_S8, dev_S8, sizeof(dev_S8));
    memcpy(h_P, dev_P, sizeof(dev_P)); memcpy(h_IP_REV, dev_IP_REV, sizeof(dev_IP_REV)); memcpy(h_SHIFTS, dev_SHIFTS, sizeof(dev_SHIFTS));
}

// =======================================================
// 2. Contenuto di bit_utils.h
// =======================================================
#define __device__
#define __host__
inline uint64_t bits_bit64(uint64_t data, int pos) { return (data >> pos) & 1; }
inline void bits_copy(uint64_t src, uint64_t* dst, int src_pos, int dst_pos, int len) { uint64_t mask = ((1ULL << len) - 1) << src_pos; uint64_t val = (src & mask) >> src_pos; *dst |= val << dst_pos; }
inline uint64_t bits_permutate(uint64_t src, int* p, int p_size, int src_size) { uint64_t res = 0; for (int i = 0; i < p_size; i++) { if (bits_bit64(src, src_size - p[i])) { res |= (1ULL << (p_size - 1 - i)); } } return res; }
inline void bits_split(uint64_t src, uint64_t* left, uint64_t* right, int size) { int half = size / 2; uint64_t mask_left = ((1ULL << half) - 1) << half; uint64_t mask_right = (1ULL << half) - 1; *left = (src & mask_left) >> half; *right = src & mask_right; }
inline void bits_split64(uint64_t src, uint64_t* left, uint64_t* right) { *left = src >> 32; *right = src & 0xFFFFFFFF; }
inline uint64_t bits_cycle_left(uint64_t src, int n, int size) { uint64_t mask = (1ULL << size) - 1; uint64_t val = src & mask; return ((val << n) | (val >> (size - n))) & mask; }

// =======================================================
// 3. Contenuto di des_kernel.h
// =======================================================
void des_create_subkeys(uint64_t key, uint64_t* keys);
uint64_t des_encode_block(uint64_t block, uint64_t* keys);
uint64_t f(uint64_t right, uint64_t key);
uint64_t full_des_encode_block(uint64_t key, uint64_t block);
void des_create_subkeys(uint64_t key, uint64_t* keys) { int* PC_1, * SHIFTS, * PC_2; PC_1 = h_PC_1; SHIFTS = h_SHIFTS; PC_2 = h_PC_2; uint64_t key_plus = bits_permutate(key, PC_1, 56, 64); uint64_t left, right; bits_split(key_plus, &left, &right, 56); uint64_t c_blocks[17], d_blocks[17]; c_blocks[0] = left; d_blocks[0] = right; for (int i = 1; i <= 16; i++) { c_blocks[i] = bits_cycle_left(c_blocks[i - 1], SHIFTS[i - 1], 28); d_blocks[i] = bits_cycle_left(d_blocks[i - 1], SHIFTS[i - 1], 28); } for (int i = 1; i <= 16; i++) { keys[i - 1] = c_blocks[i] << 28 | d_blocks[i]; keys[i - 1] = bits_permutate(keys[i - 1], PC_2, 48, 56); } }
uint64_t f(uint64_t right, uint64_t key) { int* E_BIT, ** S, * P; E_BIT = h_E_BIT; S = h_S; P = h_P; uint64_t expanded = bits_permutate(right, E_BIT, 48, 32); uint64_t xored = expanded ^ key; uint64_t b[8], s[8]; for (int i = 7; i >= 0; i--) { b[7 - i] = 0; bits_copy(xored, &b[7 - i], i * 6, 0, 6); uint64_t bb = b[7 - i]; uint64_t d_i = (bits_bit64(bb, 5) << 1) | bits_bit64(bb, 0); uint64_t d_j = (bb >> 1) & 0xF; s[7 - i] = S[7 - i][d_i * 16 + d_j]; } uint64_t s_res = 0; for (int i = 0; i < 8; ++i) s_res |= s[i] << ((7 - i) * 4); return bits_permutate(s_res, P, 32, 32); }
uint64_t des_encode_block(uint64_t block, uint64_t* keys) { int* IP, * IP_REV; IP = h_IP; IP_REV = h_IP_REV; uint64_t ip = bits_permutate(block, IP, 64, 64); uint64_t left, right; bits_split64(ip, &left, &right); for (int i = 0; i < 16; i++) { uint64_t prev_right = right; right = left ^ f(right, keys[i]); left = prev_right; } uint64_t reversed = right << 32 | left; return bits_permutate(reversed, IP_REV, 64, 64); }
uint64_t full_des_encode_block(uint64_t key, uint64_t block) { uint64_t keys[16]; des_create_subkeys(key, keys); return des_encode_block(block, keys); }

// =======================================================
// 4. Contenuto di des_crypt.cpp
// =======================================================
static char itoa64[] = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
void bits_to_string(uint64_t data, char* str) { for (int i = 0; i < 11; ++i) { str[i] = itoa64[data & 0x3F]; data >>= 6; } str[11] = '\0'; }
char* des_crypt(const char* key_str, const char* salt_str) {
    static char result[14];
    uint64_t key = 0;
    uint64_t block = 0;
    for (int i = 0; i < 8 && key_str[i]; ++i) {
        for (int j = 0; j < 7; ++j) {
            if ((key_str[i] >> (j + 1)) & 1) {
                key |= 1ULL << (i * 8 + j);
            }
        }
    }
    uint32_t salt_val = 0;
    const char* salt_ptr;
    salt_ptr = strchr(itoa64, salt_str[0]); if (salt_ptr) salt_val |= (salt_ptr - itoa64);
    salt_ptr = strchr(itoa64, salt_str[1]); if (salt_ptr) salt_val |= (salt_ptr - itoa64) << 6;
    uint64_t encrypted_block = block;
    for (int i = 0; i < 25; ++i) {
        encrypted_block = full_des_encode_block(key, encrypted_block);
    }
    result[0] = salt_str[0]; result[1] = salt_str[1];
    bits_to_string(encrypted_block, &result[2]);
    return result;
}

// =======================================================
// 5. Contenuto di cpu_cracker.cpp
// =======================================================
void launch_cracker(char* passwords, int num_passwords, char* target_hash, int* found_idx) {
    std::cout << "--- Avvio Cracking su CPU (Modalita' Parallela) ---" << std::endl;
    *found_idx = -1;
    char salt[3];
    strncpy(salt, target_hash, 2);
    salt[2] = '\0';
#pragma omp parallel for
    for (int i = 0; i < num_passwords; i++) {
        if (*found_idx != -1) {
            continue;
        }
        char* current_pass = passwords + (i * 16);
        char* hashed_pass = des_crypt(current_pass, salt);
        if (strcmp(target_hash, hashed_pass) == 0) {
#pragma omp critical
            {
                if (*found_idx == -1) {
                    *found_idx = i;
                }
            }
        }
    }
    std::cout << "--- Cracking CPU Parallelo completato ---" << std::endl;
}

// =======================================================
// 6. La nostra funzione main (VERSIONE FINALE con CARICO AUMENTATO)
// =======================================================
int main() {
    init_des_consts();

    std::string dictionary_path = "rockyou.txt";
    std::string target_hash;
    std::cout << "=== UNIFI Parallel Computing - Dictionary Cracker ===" << std::endl;
    std::cout << "Inserisci l'hash DES da crackare: ";
    std::cin >> target_hash;

    if (target_hash.length() != 13) {
        std::cerr << "Errore: L'hash DES deve essere di 13 caratteri." << std::endl;
        return 1;
    }

    std::cout << "Caricamento di " << dictionary_path << "..." << std::endl;
    std::ifstream file(dictionary_path);
    if (!file) {
        std::cerr << "Errore: Impossibile aprire " << dictionary_path << std::endl;
        return 1;
    }

    std::vector<char> passwords_buffer;
    int num_passwords = 0;
    std::string line;

    // LIMITE AUMENTATO A 5 MILIONI
    while (std::getline(file, line) && num_passwords < 5000000) {
        line.erase(std::remove_if(line.begin(), line.end(), [](unsigned char c) { return !std::isprint(c); }), line.end());
        if (line.length() > 8) { continue; }
        char fixed_line[16] = { 0 };
        strncpy(fixed_line, line.c_str(), 15);
        for (int i = 0; i < 16; i++) { passwords_buffer.push_back(fixed_line[i]); }
        num_passwords++;
    }
    file.close();
    std::cout << "Caricate " << num_passwords << " password (con lunghezza <= 8)." << std::endl;

    int found_idx = -1;
    char h_target[14];
    strncpy(h_target, target_hash.c_str(), 14);

    std::cout << "Avvio del calcolo..." << std::endl;
    auto start = std::chrono::high_resolution_clock::now();

    launch_cracker(passwords_buffer.data(), num_passwords, h_target, &found_idx);

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> diff = end - start;

    if (found_idx != -1) {
        char* found_pass_ptr = &passwords_buffer[found_idx * 16];
        std::cout << "\n[SUCCESS] Password trovata: " << found_pass_ptr << std::endl;
    }
    else {
        std::cout << "\n[FAILED] Password non trovata nel dizionario." << std::endl;
    }

    std::cout << "Tempo impiegato: " << diff.count() << " secondi." << std::endl;
    if (diff.count() > 0) {
        std::cout << "Velocita': " << (num_passwords / diff.count()) / 1000000.0 << " milioni di pass/sec." << std::endl;
    }

    return 0;
}
